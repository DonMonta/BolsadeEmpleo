<template>
  <!-- Main Post Section Start -->
  <div class="container-fluid py-5">
    <div class="container py-5">
      <div class="row g-4">
        <div class="col-lg-7 col-xl-8 mt-0">
          <div class="position-relative overflow-hidden rounded">
            <img src="@/assets/img/news-1.jpg" class="img-fluid rounded img-zoomin w-100" alt="">
            <div class="d-flex justify-content-center px-4 position-absolute flex-wrap" style="bottom: 10px; left: 0;">
              <a href="#" class="text-white me-3 link-hover"><i class="fa fa-clock"></i> 06 minute read</a>
              <a href="#" class="text-white me-3 link-hover"><i class="fa fa-eye"></i> 3.5k Views</a>
              <a href="#" class="text-white me-3 link-hover"><i class="fa fa-comment-dots"></i> 05 Comment</a>
              <a href="#" class="text-white link-hover"><i class="fa fa-arrow-up"></i> 1.5k Share</a>
            </div>
          </div>
          <div class="border-bottom py-3">
            <a href="https://iead.es/que-es-una-bolsa-de-empleo/#El-concepto-de-bolsa-de-empleo" target="_blank" class="display-4 text-dark mb-0 link-hover">Qué es una bolsa de empleo</a>
          </div>
          <p class="mt-3 mb-4">Una bolsa de empleo puede definirse como un registro de ofertas laborales e igualmente, 
            se usa como acopio de personas que ofrecen sus servicios laborales.Es por ello que se han usado como una estrategia novedosa,
            para poner en un solo lugar las ofertas de trabajo y servicios laborales, de modo de facilitar la búsqueda a los interesado...
          </p>
          <div class="bg-light p-4 rounded">
            <div class="news-2">
              <h3 class="mb-4">Story</h3>
            </div>
            <div class="row g-4 align-items-center">
              <div class="col-md-6">
                <div class="rounded overflow-hidden">
                  <img src="@/assets/img/news-2.jpg" class="img-fluid rounded img-zoomin w-100" alt="">
                </div>
              </div>
              <div class="col-md-6">
                <div class="d-flex flex-column">
                  <a href="https://es.wikipedia.org/wiki/Empleo" target="_blank" class="h3 link-hover">Conoce la Historia del Empleo</a>
                  <p class="mb-0 fs-5"><i class="fa fa-clock"> 06 minute read</i> </p>
                  <p class="mb-0 fs-5"><i class="fa fa-eye"> 3.5k Views</i></p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-5 col-xl-4">
          <div class="bg-light rounded p-4 pt-0">
            <div class="row g-4">
              <div class="col-12">
                <div class="rounded overflow-hidden">
                  <img src="@/assets/img/news-3.jpg" class="img-fluid rounded img-zoomin w-100" alt="">
                </div>
              </div>
              <div class="col-12">
                <div class="d-flex flex-column">
                  <a href="https://www.eluniverso.com/larevista/el-especialista/pueden-obligarme-a-cambiar-de-ciudad-en-el-trabajo-el-especialista-responde-nota/" target="_blank" class="h4 mb-2 link-hover">‘¿Pueden obligarme a cambiar de ciudad en el trabajo?’. El Especialista responde.</a>
                  <p class="fs-5 mb-0"><i class="fa fa-clock"> 06 minute read</i> </p>
                  <p class="fs-5 mb-0"><i class="fa fa-eye"> 3.5k Views</i></p>
                </div>
              </div>
              <div class="col-12">
                <div class="row g-4 align-items-center">
                  <div class="col-5">
                    <div class="overflow-hidden rounded">
                      <img src="@/assets/img/news-4.jpg" class="img-zoomin img-fluid rounded w-100" alt="">
                    </div>
                  </div>
                  <div class="col-7">
                    <div class="features-content d-flex flex-column">
                      <a href="https://www.eluniverso.com/noticias/economia/alza-salarial-de-10-no-deja-contentos-a-trabajadores-pero-si-a-empresas-que-destacan-que-decision-haya-sido-tecnica-nota/" target="_blank" class="h6 link-hover">Alza salarial de $ 10 no deja contentos a</a>
                      <small><i class="fa fa-clock"> 06 minute read</i> </small>
                      <small><i class="fa fa-eye"> 3.5k Views</i></small>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12">
                <div class="row g-4 align-items-center">
                  <div class="col-5">
                    <div class="overflow-hidden rounded">
                      <img src="@/assets/img/news-5.jpg" class="img-zoomin img-fluid rounded w-100" alt="">
                    </div>
                  </div>
                  <div class="col-7">
                    <div class="features-content d-flex flex-column">
                      <a href="https://www.eluniverso.com/noticias/economia/aumento-de-salario-basico-de-460-en-ecuador-este-sera-el-valor-de-las-horas-extras-vacaciones-decimos-y-jornada-nocturna-nota/" target="_blank" class="h6 link-hover">Aumento de salario básico de $ 460 en Ecuador</a>
                      <small><i class="fa fa-clock"> 06 minute read</i> </small>
                      <small><i class="fa fa-eye"> 3.5k Views</i></small>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12">
                <div class="row g-4 align-items-center">
                  <div class="col-5">
                    <div class="overflow-hidden rounded">
                      <img src="@/assets/img/news-6.jpg" class="img-zoomin img-fluid rounded w-100" alt="">
                    </div>
                  </div>
                  <div class="col-7">
                    <div class="features-content d-flex flex-column">
                      <a href="https://www.eluniverso.com/noticias/economia/el-80-de-las-empresas-preve-realizar-incrementos-salariales-en-un-promedio-de-420-en-el-2024-nota/" target="_blank" class="h6 link-hover">El 80 % de las empresas prevé realizar incrementos</a>
                      <small><i class="fa fa-clock"> 06 minute read</i> </small>
                      <small><i class="fa fa-eye"> 3.5k Views</i></small>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12">
                <div class="row g-4 align-items-center">
                  <div class="col-5">
                    <div class="overflow-hidden rounded">
                      <img src="@/assets/img/news-7.jpg" class="img-zoomin img-fluid rounded w-100" alt="">
                    </div>
                  </div>
                  <div class="col-7">
                    <div class="features-content d-flex flex-column">
                      <a href="https://www.eluniverso.com/larevista/turismo/parole-humanitario-como-sacar-el-permiso-de-trabajo-nota/" target="_blank" class="h6 link-hover">Parole humanitario: ¿Cómo sacar el permiso de trabajo?</a>
                      <small><i class="fa fa-clock"> 06 minute read</i> </small>
                      <small><i class="fa fa-eye"> 3.5k Views</i></small>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12">
                <div class="row g-4 align-items-center">
                  <div class="col-5">
                    <div class="overflow-hidden rounded">
                      <img src="@/assets/img/news-8.jpg" class="img-zoomin img-fluid rounded w-100" alt="">
                    </div>
                  </div>
                  <div class="col-7">
                    <div class="features-content d-flex flex-column">
                      <a href="https://www.eluniverso.com/noticias/informes/cual-es-el-ingreso-real-de-los-trabajadores-ecuatorianos-nota/" target="_blank" class="h6 link-hover">¿Cuál es el ingreso real de los trabajadores ecuatorianos?</a>
                      <small><i class="fa fa-clock"> 06 minute read</i> </small>
                      <small><i class="fa fa-eye"> 3.5k Views</i></small>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12">
                <div class="row g-4 align-items-center">
                  <div class="col-5">
                    <div class="overflow-hidden rounded">
                      <img src="@/assets/img/news-9.jpg" class="img-zoomin img-fluid rounded w-100" alt="">
                    </div>
                  </div>
                  <div class="col-7">
                    <div class="features-content d-flex flex-column">
                      <a href="https://www.eluniverso.com/noticias/economia/que-tan-recomendable-es-mensualizar-el-decimo-tercer-sueldo-nota/" target="_blank" class="h6 link-hover">¿Qué tan recomendable es mensualizar el décimo tercer sueldo?</a>
                      <small><i class="fa fa-clock"> 06 minute read</i> </small>
                      <small><i class="fa fa-eye"> 3.5k Views</i></small>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Main Post Section End -->
  </template>
  <style>
  @import url('@/assets/styles.css');
  </style>